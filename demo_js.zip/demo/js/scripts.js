// const age = prompt("Entrez votre âge");

// if (age < 18) { // On vérifie si on a moins de 18 ans
//     console.log("La personne est mineure");
// } else if (age < 65) { // On vérifie si on a moins de 65 ans
//     console.log("La personne est adulte");
// } else { // Tous les cas non validés au dessus
//     console.log("La personne est sénior");
// }

// for (let compteur = 25; compteur <= 50; compteur++){
//     console.log(compteur);
// }

// let compteur = 10;

// while (compteur < 5){
//     console.log(compteur);
//     compteur++;
// } 

// /**
//  * 
//  * @param {*} nom 
//  * @param {*} prenom 
//  */
// function direBonjour(nom, prenom)
// {
//     console.log(`Bonjour ${prenom} ${nom} !`);
// }



// /**
//  * Cette fonction additionne 2 nombres
//  * @param {Number} nombre1 Entrer ici un nombre
//  * @param {Number} nombre2 Nombre 2
//  * @returns Number
//  */
// function additionner(nombre1 = 0, nombre2 = 10)
// {
//     let addition = nombre1 + nombre2;
//     return addition;  
// }

// console.log(additionner);

// let total = additionner(12);
// console.log(total);

// direBonjour("Mars", "Bruno");



// total = additionner(12, 78);
// console.log(total);






// direBonjour("Albert");





// direBonjour(252);

























// for (let nombre = 1; nombre < 100; nombre++) {
//     if(nombre % 3 === 0 && nombre % 5 === 0){
//         console.log("FizzBuzz");
//         continue;
//     }
//     if(nombre % 3 === 0){
//         console.log("Fizz");
//         continue;
//     }
//     if(nombre % 5 === 0){
//         console.log("Buzz");
//         continue;
//     }
//     console.log(nombre);
// }


// for(let nombre = 1; nombre <= 30; nombre++) console.log((nombre % 3 ? "" : "Fizz") + (nombre % 5 ? "" : "Buzz") || nombre);






// // Fonction pour vérifier si un nombre est premier
// function estPremier(num) {
//     if (num <= 1) {
//         return false;
//     }
//     for (let i = 2; i <= Math.sqrt(num); i++) {
//         if (num % i === 0) {
//             return false;
//         }
//     }
//     return true;
// }
// console.log(estPremier(23));







// for(let nombre = 2; nombre <= 1000; nombre++){
//     if(estPremier(nombre)){
//         console.log(nombre);
//     }
// }



// let voyelles = ["a", "e", "i", "o", "u", "y"];

// let phrase = prompt("Entrez une phrase").toLowerCase();

// let count = 0;
// for(let lettre of phrase){
//     if(voyelles.includes(lettre)){
//         count++;
//     }
// }

// console.log(count);

// const genere = Math.floor(Math.random() * 10) + 1;
// let nombre;
// do{
//     nombre = Number(prompt("Entrez un nombre entre 1 et 10"));
//     if(nombre < genere){
//         console.log(`${nombre} - Trop petit`);
//         continue;
//     }
//     if(nombre > genere){
//         console.log(`${nombre} - Trop grand`);
//         continue;
//     }
// }while(nombre != genere);

// console.log(`${nombre} - Gagné`);

const choix = prompt("Entrez votre choix");
const temp = Number(prompt("Entrez la température"));
let converti;

switch(choix){
    case "1":
        converti = temp * 9/5 + 32;
        console.log(`${temp}°C fait ${converti}°F`);
        break;
    case "2":
        converti = (temp - 32) * 5/9;
        console.log(`${temp}°F fait ${converti}°C`);
        break;
    default:
        console.log("Mauvais choix");
}
